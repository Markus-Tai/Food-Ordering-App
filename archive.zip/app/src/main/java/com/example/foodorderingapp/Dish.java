package com.example.foodorderingapp;

public class Dish {

    // Public properties
    public String name;
    public String description;
    public Integer priceInCents;
    public String imageResourceName;


}
